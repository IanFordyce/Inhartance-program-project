﻿using System;

namespace Fordyce.App05Program
{
    public class IO
    {
        public IO() { } 

        public String theUsersInputString(string message)
        {
            Console.WriteLine("\n" + message.Trim() + "\n");
            return Console.ReadLine();
        }

        public void theDisplayedMessage(string message)
        {
            Console.WriteLine("\n" + message.Trim() + "\n");
        }
    }
}

