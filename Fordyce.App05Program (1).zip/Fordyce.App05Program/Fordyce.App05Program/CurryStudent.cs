﻿using System;

namespace Fordyce.App05Program
{

    public class CurryStudent : Students
    {
        private String _major = null;
        private double _colonelCash = -99.99;
        private String _livingStatus = null;

        // Reference - enumeration based on code is from class
        private enum _listOf_majors { accounting = 1, biochemistry = 2, biology = 3, business_administration = 4, communication = 5, computer_science = 6, environmental_science = 7, forensic_science = 8, graphic_design = 9, marketing = 10, nursing = 11, psychology = 12, public_health_and_wellness = 13, sport_and_recreation_management = 14, studio_arts = 15 }


        public CurryStudent()
        {
            IO inputOutput = new IO();

            String message = "What is the students Major?";
            set_major(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The Students major is: " + get_major());

            message = "What is this students living status?";
            set_livingStatus(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students living status is: " + get_livingStatus());

            message = "How much Colonel Cash does this student have?";
            set_colonelCash(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The student has: " + get_colonelCash() + " dollar in Colonel Cash.");
        }

        public bool set_major(String a)
        {
            if (a == null)
            {
                return false;
            }

            String tempString = a.ToLower().Trim().Replace(" ", "_");

            for (int count = 1; count <= 15; count++)
            {
                if (((_listOf_majors)count).ToString().CompareTo(tempString) == 0)
                {
                    _major = a;
                    return true;
                }
            }
            return false;
        }

        public String get_major()
        {
            if (_major == null)
            {
                return "The major was not intialized";
            }

            return _major;
        }

        public bool set_livingStatus(string a)
        {
            if (a == null)
            {
                return false;
            }
            else if (a.ToLower().Equals("commuter") || a.ToLower().Equals("resident"))
            {
                _livingStatus = a;
                return false;
            }
            return false;
        }

        public String get_livingStatus()
        {
            if (_livingStatus == null)
            {
                return "The living status was not intialized";
            }

            return _livingStatus;
        }

        public bool set_colonelCash(String a)
        {
            InputValidation validDouble = new InputValidation();

            if (a.StartsWith('$'))
            {
                a = a.Replace("$", String.Empty);
            }

            if (a == null)
            {
                return false;
            }
            else if (validDouble.stringToDouble(a) && Convert.ToDouble(a) >= 0)
            {
                _colonelCash = Convert.ToDouble(a);
                return true;
            }
            return false;
        }

        public String get_colonelCash()
        {
            if (_colonelCash == -99.99)
            {
                return " The amount of Colonel Cash was not intialized ";
            }
            return _colonelCash.ToString();
        }
    }
}