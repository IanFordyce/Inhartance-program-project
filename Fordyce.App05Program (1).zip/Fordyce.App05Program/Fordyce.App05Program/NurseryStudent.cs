﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fordyce.App05Program
{
    public class NurseryStudent : Students
    {
        private String _guardianFirstName = null;
        private String _guardianLastName = null;
        private long _guardianPhoneNumber = -99;
        private Time _pickUpTime = null;

        public NurseryStudent()
        {
            IO inputOutput = new IO();

            String message = "What is the Guardian's First Name?";
            set_guardianFirstName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The guardian's first name is: " + get_guardianFirstName());

            message = "What is the Guardian's Last Name?";
            set_guardianLastName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The Guardian's last name is: " + get_guardianFirstName());

            message = "What is the guardians Phone Number?";
            set_guardianPhoneNumber(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The Guardian's Phone number is: " + get_guardianPhoneNumber());

            message = "What is this students pick up time? Please enter with the seconds";
            set_pickUpTime(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students pick up time is: " + get_pickUpTime());
        }

        public bool set_guardianFirstName(String a)
        {
            InputValidation validLetter = new InputValidation();

            if (validLetter.containsNoNumbers(a) || a == null)
            {
                return false;
            }

            _guardianFirstName = a;

            return true;
        }

        public String get_guardianFirstName()
        {
            if (_guardianFirstName == null)
            {
                return "The dance partner's First Name was not initialized.";
            }
            return _guardianFirstName;
        }

        public bool set_guardianLastName(String a)
        {
            InputValidation validLetter = new InputValidation();

            if (validLetter.containsNoNumbers(a) || a == null)
            {
                return false;
            }

            _guardianLastName = a;

            return true;
        }

        public String get_guardianLastName()
        {
            if (_guardianLastName == null)
            {
                return "The dance partner's First Name was not initialized.";
            }
            return _guardianLastName;
        }

        public bool set_guardianPhoneNumber(String a)
        {
            if (a == "-99")
            {
                return false;
            }

            a = a.Trim().Replace("-", String.Empty).Replace("(", String.Empty).Replace(")", String.Empty);

            if (a.Length <= 15 && a.Length > 5)
            {
                _guardianPhoneNumber = Convert.ToInt64(a);
            }
            return false;
        }

        public String get_guardianPhoneNumber()
        {
            if (_guardianPhoneNumber == -99)
            {
                return "The guardian's Phone Number was not initialized.";
            }
            return _guardianPhoneNumber.ToString();
        }

        public bool set_pickUpTime(String a)
        {
            if (a == null)
            {
                return false;
            }

            _pickUpTime = new Time(a);
            return true;
        }

        public String get_pickUpTime()
        {
            if (_pickUpTime == null)
            {
                return "The pickup time was not initialized.";
            }
            return _pickUpTime.showTime();
        }
    }
}