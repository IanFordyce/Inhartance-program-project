﻿using System;

namespace Fordyce.App05Program
{
    internal class Date
    {
        private int _month = -99;
        private int _day = -99;
        private int _year = -99;

        // Reference - enumeration based on code is from class
        enum _monthsIn_year { January = 1, February = 2, March = 3, April = 4, May = 5, June = 6, July = 7, August = 8, September = 9, October = 10, November = 11, December = 12 }

        enum _MonthsAsShortIn_year { jan = 1, feb = 2, mar = 3, apr = 4, may = 5, jun = 6, jul = 7, aug = 8, sep = 9, oct = 10, nov = 11, dec = 12 }

        public Date()
        {
            IO inputOutput = new IO();

            String message = "Please enter a year as a four digit number";
            setYear(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The inputted year is " + getYear());

            message = "Please enter a Month a Word";
            setMonth(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The inputted Month is " + getMonth());

            message = "Please enter a day as a Number";
            setDay(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The inputted day is " + getDay());
        }
        public Date(String year, String month, String day)
        {
            IO inputOutput = new IO();

            setYear(year);

            inputOutput.theDisplayedMessage("The inputted year is " + getYear());

            setMonth(month);

            inputOutput.theDisplayedMessage("The inputted Month is " + getMonth());

            setDay(day);

            inputOutput.theDisplayedMessage("The inputted day is " + getDay());
        }

        public bool setMonth(string a)
        {
            InputValidation validNumber = new InputValidation();

            if (validNumber.stringToInt(a))
            {
                if (Convert.ToInt32(a) >= 1 && Convert.ToInt32(a) <= 12)
                {
                    _month = Convert.ToInt32(a);
                    return true;
                }
                return false;
            }


            if (a.Length < 3)
            {
                return false;
            }

            String tempString = a.Substring(0, 3).ToLower();

            for (int count = 1; count <= 12; count++)
            {
                if (((_MonthsAsShortIn_year)count).ToString().CompareTo(tempString) == 0)
                {
                    _month = (short)count;
                    return true;
                }
            }
            return false;
        }

        public string getMonth()
        {
            if (_month.Equals(-99))
            {
                return "The day was not intialized";
            }
            return ((_monthsIn_year)_month).ToString();
        }

        public bool setDay(string a)
        {
            InputValidation validNumber = new InputValidation();

            if (validNumber.stringToInt(a))
            {
                if ((_year % 4 == 0) && (_year % 100 != 0) && Convert.ToInt32(a) == 30 || (_year % 400 == 0) && Convert.ToInt32(a) == 30) // Checks for Leap year
                {
                    return false;
                }
                else if (Convert.ToInt32(a) >= 1 && Convert.ToInt32(a) <= 31)
                {
                    _day = Convert.ToInt32(a);
                    return true;
                }
            }
            return false;
        }

        public String getDay()
        {
            if (_day == -99)
            {
                return "Day is not initialized or is a Leap year";
            }
            return _day.ToString();
        }

        public bool setYear(string a)
        {
            InputValidation validNumber = new InputValidation();

            if (validNumber.stringToInt(a))
            {
                if (a.Length == 4 && a[0] <= '2')
                {
                    _year = Convert.ToInt32(a);
                    return true;
                }
            }
            return false;
        }

        public String getYear()
        {
            if (_year == -99)
            {
                return "The year was not intialized";
            }
            return _year.ToString();
        }
    }
}

