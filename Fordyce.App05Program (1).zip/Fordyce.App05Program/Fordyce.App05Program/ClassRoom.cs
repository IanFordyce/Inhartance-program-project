﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Fordyce.App05Program
{
    public class ClassSeats
    {
        private Students enrolledStudent = null;

        private int numberOfSeats;

        public ClassSeats()
        {
            IO inputOutput = new IO();

            String message = "Please enter the number of seats in this Classroom";
            setNumberOfSeats(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("There are " + getNumberOfSeats() + " seats in this class");

            setEnrolledStudent();

            setEnrolledStudent("Ian", "Fordyce ", "Male", "4.0", "999999999", "2001", "march", "16", "@01078321");

            getEnrolledStudent();

            setEnrolledStudent("Male", "4.0", "999999999", "2001", "march", "16", "@01019664");

            getEnrolledStudent();

            setEnrolledStudent("Male", "4.0", "999999999", "2001", "march", "16");

            getEnrolledStudent();
        }

        public bool setEnrolledStudent()
        {
            enrolledStudent = new Students();
            return true;
        }

        public bool setEnrolledStudent(String firstName, String lastName, String gender, String gradePointAverage, String socialSecurityNumber, String birthYear, String birthMonth, String birthday, String studentID)
        {
            enrolledStudent = new Students(firstName, lastName, gender, gradePointAverage, socialSecurityNumber, birthYear, birthMonth, birthday, studentID);
            return true;
        }

        public bool setEnrolledStudent(String gender, String gradePointAverage, String socialSecurityNumber, String birthYear, String birthMonth, String birthday, String studentID)
        {
            enrolledStudent = new Students(gender, gradePointAverage, socialSecurityNumber, birthYear, birthMonth, birthday, studentID);
            return true;
        }

        public bool setEnrolledStudent(String gender, String gradePointAverage, String socialSecurityNumber, String birthYear, String birthMonth, String birthday)
        {
            enrolledStudent = new Students(gender, gradePointAverage, socialSecurityNumber, birthYear, birthMonth, birthday);
            return true;
        }

        public Students getEnrolledStudent()
        {
            return enrolledStudent;
        }

        public bool setNumberOfSeats(string a)
        {
            InputValidation validNumber = new InputValidation();

            if (validNumber.stringToInt(a))
            {
                numberOfSeats = Convert.ToInt32(a);
                return true;
            }
            return false;
        }

        public string getNumberOfSeats()
        {
            if (numberOfSeats != -99)
            {
                return numberOfSeats.ToString();
            }
            return "Number of seats was not intialized";
        }
    }
}
