﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fordyce.App05Program
{
    public class TonyesJudo : Students
    {
        private String _beltColor = null;
        private double _heightInInches = -99.99;
        private double _weightInPounds = -99.99;

        public TonyesJudo()
        {
            IO inputOutput = new IO();

            String message = "What is the student's belt color?";
            set_beltColor(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The student's belt color is: " + get_beltColor());

            message = "What is the students height in inches?";
            set_heightInInches(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The student's height in inches is: " + get_heightInInches());

            message = "What is the students weight in pounds?";
            set_weightInPounds(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The student's weight in pounds is: " + get_weightInPounds());
        }

        public bool set_beltColor(String a)
        {
            InputValidation validLetter = new InputValidation();

            if (validLetter.containsNoNumbers(a) || a == null)
            {
                return false;
            }

            _beltColor = a;
            return true;
        }

        public String get_beltColor()
        {
            if (_beltColor == null)
            {
                return "The belt color was not initialized";
            }
            return _beltColor;
        }

        public bool set_heightInInches(String a)
        {
            if (Convert.ToDouble(a) == -99.99)
            {
                return false;
            }
            else if (Convert.ToInt32(a) >= 42 && Convert.ToInt32(a) <= 90)
            {
                _heightInInches = Convert.ToInt32(a);
                return true;
            }
            return false;
        }

        public String get_heightInInches()
        {
            if (_heightInInches == -99.99)
            {
                return "The height in inches was not initialized";
            }

            return _heightInInches.ToString();
        }

        public bool set_weightInPounds(String a)
        {
            if (Convert.ToDouble(a) == -99.99)
            {
                return false;
            }
            else if (Convert.ToInt32(a) >= 50 && Convert.ToInt32(a) <= 350)
            {
                _weightInPounds = Convert.ToInt32(a);
                return true;
            }
            return false;
        }

        public String get_weightInPounds()
        {
            if (_weightInPounds == -99.99)
            {
                return "The weight in pounds was not initialized";
            }

            return _weightInPounds.ToString();
        }
    }
}