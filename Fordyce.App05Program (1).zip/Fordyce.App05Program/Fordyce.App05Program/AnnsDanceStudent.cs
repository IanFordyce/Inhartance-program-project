﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fordyce.App05Program
{
    internal class AnnsDanceStudent : Students
    {
        private String _danceStyle = null;
        private double _shoeSize = -99.99;
        private String _dancePartnerFirstName = null;
        private String _dancePartnerLastName = null;

        public AnnsDanceStudent()
        {
            IO inputOutput = new IO();

            String message = "What is the students Dance Style?";
            set_danceStyle(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students Dance Style is: " + get_danceStyle());

            message = "What is the students Shoe Size?";
            set_shoeSize(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("students shoe size is: " + get_shoeSize());

            message = "What is their dance partner's first name?";
            set_dancePartnersFirstName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The dance partners first name is: " + get_dancePartnersFirstName());

            message = "What is their dance partner's last name?";

            set_dancePartnersFirstName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The dance partners first name is: " + get_dancePartnersFirstName());
        }

        public bool set_danceStyle(String a)
        {
            InputValidation ValidLetters = new InputValidation();

            if (a == null)
            {
                return false;
            }
            else if (!ValidLetters.containsNoNumbers(a))
            {
                _danceStyle = a;
                return true;
            }
            return false;

        }

        public String get_danceStyle()
        {
            if (_danceStyle == null)
            {
                return "The dance style was not intialized";
            }
            return _danceStyle;
        }

        public bool set_shoeSize(string a)
        {
            InputValidation validDouble = new InputValidation();

            if (a == null)
            {
                return false;
            }
            else if (!validDouble.stringToInt(a) && Convert.ToDouble(a) > 0)
            {
                _shoeSize = Convert.ToDouble(a);
            }
            return false;
        }

        public String get_shoeSize()
        {
            if (_shoeSize == -99.99)
            {
                return "The shoe size was not intialized";
            }
            return _shoeSize.ToString();
        }

        public bool set_dancePartnersFirstName(String a)
        {
            InputValidation validLetter = new InputValidation();

            if (validLetter.containsNoNumbers(a) || a == null)
            {
                return false;
            }

            _dancePartnerFirstName = a;

            return true;
        }

        public String get_dancePartnersFirstName()
        {
            if (_dancePartnerFirstName == null)
            {
                return "The dance partner's First Name was not initialized";
            }
            return _dancePartnerFirstName;
        }

        public bool set_dancePartnersLastName(string a)
        {
            InputValidation validLetter = new InputValidation();

            if (validLetter.containsNoNumbers(a) || a == null)
            {
                return false;
            }

            _dancePartnerLastName = a;
            return true;
        }

        public String get_dancePartnersLastName()
        {
            if (_dancePartnerLastName == null)
            {
                return "The dance partner's Last Name was not initialized";
            }
            return _dancePartnerLastName;
        }
    }
}