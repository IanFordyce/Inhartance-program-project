﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fordyce.App05Program
{
    public class Students
    {
        private String firstName = null;
        private String lastName = null;
        private char gender = 'x';
        private double gradePointAverage = -99.9;
        private int socialSecurityNumber = -99;
        private Date birthday = null;
        private int age = -99;
        private String studentID = null;

        public Students()
        {
            IO inputOutput = new IO();

            string message = "What is the student's first name?";
            setFirstName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students first name is: " + getFirstName());

            message = "What is the student's last name?";
            setLastName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students's last name is: " + getLastName());

            message = "What is the student's gender? Please enter with Male, Female, or Other";
            setGender(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The student's gender is " + getGender());

            message = "What is the student's Grade Point Average?";
            setGradePointAverage(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The student's Grade Point Average is: " + getGradePointAverage());

            message = "What is the student's Social Security Number?";
            setSocialSecurityNumber(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The student's Social Security Number is: " + getSocialSecurityNumber());

            message = "What is the student's birthday?";
            inputOutput.theDisplayedMessage(message);
            setBirthday();

            inputOutput.theDisplayedMessage("The students birthday is " + getBirthday());

            setAge();

            inputOutput.theDisplayedMessage("The student is " + getAge() + " years old.");

            message = "What is this students ID Number? The number should start with a '@' and be 9 characters long in total.";
            setStudentID(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The Students ID Number is " + getStudentID());
        }

        public Students(String firstName, String lastName, String gender, String gradePointAverage, String socialSecurityNumber, String birthYear, String birthMonth, String birthday, String studentID)
        {
            IO inputOutput = new IO();

            setFirstName(firstName);

            inputOutput.theDisplayedMessage("The students first name is: " + getFirstName());

            setLastName(lastName);

            inputOutput.theDisplayedMessage("The students's last name is: " + getLastName());

            setGender(gender);

            inputOutput.theDisplayedMessage("The student's gender is " + getGender());

            setGradePointAverage(gradePointAverage);

            inputOutput.theDisplayedMessage("The student's Grade Point Average is: " + getGradePointAverage());

            setSocialSecurityNumber(socialSecurityNumber);

            inputOutput.theDisplayedMessage("The student's Social Security Number is: " + getSocialSecurityNumber());

            setBirthday(birthYear, birthMonth, birthday);

            inputOutput.theDisplayedMessage("The students birthday is " + getBirthday());

            setAge();

            inputOutput.theDisplayedMessage("The student is " + getAge() + " years old.");

            setStudentID(studentID);

            inputOutput.theDisplayedMessage("The Students ID Number is " + getStudentID());
        }

        public Students(String gender, String gradePointAverage, String socialSecurityNumber, String birthYear, String birthMonth, String birthday, String studentID)
        {
            IO inputOutput = new IO();

            string message = "What is the student's first name?";
            setFirstName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students first name is: " + getFirstName());

            message = "What is the student's last name?";
            setLastName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students's last name is: " + getLastName());

            setGender(gender);

            inputOutput.theDisplayedMessage("The student's gender is " + getGender());

            setGradePointAverage(gradePointAverage);

            inputOutput.theDisplayedMessage("The student's Grade Point Average is: " + getGradePointAverage());

            setSocialSecurityNumber(socialSecurityNumber);

            inputOutput.theDisplayedMessage("The student's Social Security Number is: " + getSocialSecurityNumber());

            setBirthday(birthYear, birthMonth, birthday);

            inputOutput.theDisplayedMessage("The students birthday is " + getBirthday());

            setAge();

            inputOutput.theDisplayedMessage("The student is " + getAge() + " years old.");

            setStudentID(studentID);

            inputOutput.theDisplayedMessage("The Students ID Number is " + getStudentID());
        }

        public Students(String gender, String gradePointAverage, String socialSecurityNumber, String birthYear, String birthMonth, String birthday)
        {
            IO inputOutput = new IO();

            string message = "What is the student's first name?";
            setFirstName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students first name is: " + getFirstName());

            message = "What is the student's last name?";
            setLastName(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The students's last name is: " + getLastName());

            setGender(gender);

            inputOutput.theDisplayedMessage("The student's gender is " + getGender());

            setGradePointAverage(gradePointAverage);

            inputOutput.theDisplayedMessage("The student's Grade Point Average is: " + getGradePointAverage());

            setSocialSecurityNumber(socialSecurityNumber);

            inputOutput.theDisplayedMessage("The student's Social Security Number is: " + getSocialSecurityNumber());

            setBirthday(birthYear, birthMonth, birthday);

            inputOutput.theDisplayedMessage("The students birthday is " + getBirthday());

            setAge();

            inputOutput.theDisplayedMessage("The student is " + getAge() + " years old.");

            message = "What is this students ID Number? The number should start with a '@' and be 9 characters long in total.";
            setStudentID(inputOutput.theUsersInputString(message));

            inputOutput.theDisplayedMessage("The Students ID Number is " + getStudentID());
        }

        public bool setFirstName(string a)
        {
            InputValidation validLetter = new InputValidation();

            if (validLetter.containsNoNumbers(a) || a == null)
            {
                return false;
            }

            firstName = a;

            return true;
        }

        public string getFirstName()
        {
            if (firstName == null)
            {
                return " was not initialized";
            }
            return firstName;
        }

        public bool setLastName(string a)
        {
            InputValidation validLetter = new InputValidation();

            if (validLetter.containsNoNumbers(a) || a == null)
            {
                return false;
            }

            lastName = a;
            return true;
        }

        public string getLastName()
        {
            if (lastName == null)
            {
                return " was not initialized";
            }
            return lastName;
        }

        public bool setGender(string a)
        {
            switch (a.ToLower())
            {
                case "male":
                    gender = 'm';
                    return true;
                case "female":
                    gender = 'f';
                    return true;
                case "other":
                    gender = 'o';
                    return true;
                default:
                    gender = 'x';
                    return false;
            }
        }

        public string getGender()
        {
            switch (gender)
            {
                case 'm':
                    return "Male";
                case 'f':
                    return "Female";
                case 'o':
                    return "Other";
                default:
                    return "not initialized";
            }
        }

        public bool setGradePointAverage(string a)
        {
            double gPA = 0.0;

            if (double.TryParse(a, out gPA))
            {
                if (gPA >= 0.0 && gPA <= 4.0 && !gPA.ToString().Contains('-'))
                    gradePointAverage = gPA;
                return true;
            }
            return false;
        }

        public string getGradePointAverage()
        {
            if (gradePointAverage == -99.9)
            {
                return "GPA was not intialized";
            }
            return gradePointAverage.ToString();
        }

        public bool setSocialSecurityNumber(string a)
        {
            int sSN;

            if (int.TryParse(a, out sSN))
            {
                if (sSN.ToString().Length == 9 && !sSN.ToString().Contains('-'))
                    socialSecurityNumber = sSN;
                return true;
            }
            return false;
        }

        public string getSocialSecurityNumber()
        {
            if (socialSecurityNumber == -99)
            {
                return "The Social Security Number was not intialized";
            }
            return socialSecurityNumber.ToString().Insert(5, "-").Insert(3, "-");
        }

        public bool setBirthday()
        {
            birthday = new Date();
            return true;
        }

        public bool setBirthday(String year, String month, String day)
        {
            birthday = new Date(year, month, day);
            return true;
        }

        public string getBirthday()
        {
            if (birthday != null)
            {
                return birthday.getMonth() + "/" + birthday.getDay() + "/" + birthday.getYear();
            }
            return "The Birthday was not intialized";
        }

        public bool setAge()
        {
            age = (DateTime.Now.Year - Convert.ToInt32(birthday.getYear()) - 1);
            return true;
        }

        public String getAge()
        {
            if (age == -99)
            {
                return "The age was not was not intialized";
            }
            return age.ToString();
        }

        public bool setStudentID(string a)
        {
            if (a.Length == 9 && a.StartsWith("@"))
            {
                for (int count = 1; count < a.Length; count++)
                {
                    if (a[count] < '0' || a[count] > '9')
                    {
                        return false;
                    }
                }
                studentID = a;
                return true;
            }
            return false;
        }

        public String getStudentID()
        {
            if (studentID == null)
            {
                return "The student ID was not intialized";
            }
            return studentID.ToString();
        }
    }
}

